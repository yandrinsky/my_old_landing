function test(argument1, arg2) {
	return argument1 * arg2;
}
